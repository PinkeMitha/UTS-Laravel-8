@extends('layouts.app')

@section('title', 'Sepatus')

@section('content')
<a href="/sepatus/create" class="card-link btn-primary">Tambah sepatu</a>
@foreach ($sepatus as $sepatu)

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <a href="/sepatus/{{ $sepatu['id']}}" class="card-title">{{ $sepatu['name'] }}</a>
    <p class="card-text">{{ $sepatu['description']}}</p>
      <hr>
      <a href="" class="card-link btn-primary">Tambah Item</a>
          @foreach($sepatu->friends as $friend)
          <li>{{$friend->nama}} </li>
          @endforeach
      <hr>
    <a href="//sepatus/{{$sepatu['id']}}/edit" class="card-link btn-warning">Edit Item</a>
    <form action="/sepatus/{{ $sepatu['id']}}" method="POST">
      @csrf
      @method('DELETE')
    <button class="card-link btn-danger">Delete Item</button>
  </form>
  </div>
</div>
    
@endforeach
<div>
  {{ $sepatus->links() }}
</div>
@endsection